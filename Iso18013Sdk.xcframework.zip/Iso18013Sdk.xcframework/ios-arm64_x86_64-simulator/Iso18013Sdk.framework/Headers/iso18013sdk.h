//
//  iso18013sdk.h
//  iso18013sdk
//
//  Created by Ruben Pacheco Lopez on 12/12/23.
//

#import <Foundation/Foundation.h>

//! Project version number for iso18013sdk.
FOUNDATION_EXPORT double iso18013sdkVersionNumber;

//! Project version string for iso18013sdk.
FOUNDATION_EXPORT const unsigned char iso18013sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iso18013sdk/PublicHeader.h>


